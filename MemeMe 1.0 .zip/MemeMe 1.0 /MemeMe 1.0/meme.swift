//
//  meme.swift
//  MemeMe 1.0
//
//  Created by MacOs on 19/04/2019.
//  Copyright © 2019 AliAlbulayhi. All rights reserved.
//

import UIKit

struct Meme {
    var topText: String
    var bottomText: String
    var originalImage: UIImage
    var memedImage : UIImage
}
